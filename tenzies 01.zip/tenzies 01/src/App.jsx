import './App.css';
import TenziBoard from './components/TenziBoard.jsx';

function App() {
  return (
    <div className="App">
      <TenziBoard />
    </div>
  );
}

export default App;
